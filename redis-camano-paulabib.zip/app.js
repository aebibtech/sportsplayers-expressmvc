const app = require('./system/ExpressMVC');

app();